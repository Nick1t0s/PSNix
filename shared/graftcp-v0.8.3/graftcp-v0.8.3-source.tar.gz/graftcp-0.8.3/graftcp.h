/*
 * graftcp
 * Copyright (C) 2018, 2020-2026 Hmgle <dustgle@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
#ifndef GRAFTCP_H
#define GRAFTCP_H

#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <errno.h>
#include <limits.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/user.h>
#if defined(__x86_64__)
#include <sys/reg.h>
#include <linux/sched.h>
#elif defined(__arm__)
#include <asm/ptrace.h>
#elif defined(__arm64__) || defined(__aarch64__)
#include <asm/ptrace.h>
#include <linux/elf.h>
#endif
#include <sys/syscall.h>
#include <fcntl.h>
#include <assert.h>

#include "uthash.h"

#ifndef SOCK_TYPE_MASK
#define SOCK_TYPE_MASK 0xf
#endif

#if defined(__arm__) || defined(__arm64__) || defined(__aarch64__)

#ifndef SYS_socket
#define SYS_socket __NR_socket
#endif

#ifndef SYS_connect
#define SYS_connect __NR_connect
#endif

#ifndef SYS_sendto
#define SYS_sendto __NR_sendto
#endif

#ifndef SYS_sendmsg
#define SYS_sendmsg __NR_sendmsg
#endif

#ifndef SYS_close
#define SYS_close __NR_close
#endif

#ifndef SYS_clone
#define SYS_clone __NR_clone
#endif

#ifndef SYS_dup
#define SYS_dup __NR_dup
#endif

#ifndef SYS_dup2
#ifdef __NR_dup2
#define SYS_dup2 __NR_dup2
#endif
#endif

#ifndef SYS_dup3
#define SYS_dup3 __NR_dup3
#endif

#ifndef SYS_fcntl
#define SYS_fcntl __NR_fcntl
#endif

#ifndef SYS_fcntl64
#ifdef __NR_fcntl64
#define SYS_fcntl64 __NR_fcntl64
#endif
#endif

#ifndef SYS_exit
#define SYS_exit __NR_exit
#endif

#ifndef SYS_exit_group
#define SYS_exit_group __NR_exit_group
#endif

#endif

#define satosin(x)  ((struct sockaddr_in *) &(x))
#define SOCKADDR(x) (satosin(x)->sin_addr.s_addr)
#define SOCKPORT(x) (satosin(x)->sin_port)

#define satosin6(x)  ((struct sockaddr_in6 *) &(x))
#define SOCKPORT6(x) (satosin6(x)->sin6_port)

#define FLAG_STARTUP    00002
#define FLAG_INSYSCALL  00010

#define exiting(pinfp)  ((pinfp)->flags & FLAG_INSYSCALL)

#define TRACKED_SOCKET_INITIAL_CAP 8U

struct tracked_socket {
	int fd;
	int domain;
	int type;
};

struct proc_info {
	pid_t pid;
	int flags;
	int csn;		/* current syscall number */
	bool pending_socket;
	int pending_socket_domain;
	int pending_socket_type;
	bool pending_dup;
	int pending_dup_oldfd;
	int pending_dup_newfd;
	bool pending_dup_fixed;
	bool pending_sockaddr_restore;
	long sockaddr_restore_addr;
	size_t sockaddr_restore_len;
	unsigned char sockaddr_restore[sizeof(struct sockaddr_in6)];
	unsigned int tracked_socket_count;
	unsigned int tracked_socket_cap;
	struct tracked_socket *tracked_sockets;
	UT_hash_handle hh;
};

struct proc_info *find_proc_info(pid_t pid);
struct proc_info *alloc_proc_info(pid_t pid);
void free_proc_info(struct proc_info *p);

int track_socket_fd(struct proc_info *pinfp, int fd, int domain, int type);
int copy_tracked_socket_fd(struct proc_info *dst, const struct proc_info *src,
			   int oldfd, int newfd);
int copy_tracked_sockets(struct proc_info *dst, const struct proc_info *src);
bool is_tracked_socket_fd(struct proc_info *pinfp, int fd);
bool is_tracked_stream_socket_fd(struct proc_info *pinfp, int fd);
bool is_tracked_dgram_socket_fd(struct proc_info *pinfp, int fd);
void untrack_socket_fd(struct proc_info *pinfp, int fd);

int get_syscall_number(pid_t pid);
int get_retval(pid_t pid);
void set_retval(pid_t pid, long new_val);
long get_syscall_arg(pid_t pid, int order);

int getdata(pid_t child, long addr, void *dst, size_t len);
int putdata(pid_t child, long addr, const void *src, size_t len);

#endif
